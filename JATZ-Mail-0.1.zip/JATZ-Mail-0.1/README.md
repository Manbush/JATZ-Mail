# JATZ-Mail

## What it does
This is an email sending code where you can send emails from any email of your choice.
There are a few fun games included.
To open "Dev" section look through the code for the password. There are few more helpful things you can do there.



## Requirements
- It can use any type of email address 
- You will also have to edit the sender's email account to allow for less secure apps (Python)
- As well as the actual code you must download the JATZMAILICON.png as well.

## Disclaimer

If you do this your account may be vulernable so it's better if you make a new email just for this
Here is the link to allow https://myaccount.google.com/lesssecureapps?pli=1&rapt=AEjHL4MtLCEKC6Ca2DgaotIVA-L_fNKnkma8Z3CfHNOTKI0SyaZc1tqdh5kziqV20GiqAw7S6JAxT_nmkQtdHxS8l4UC_eRptw

## How to run
When downloaded, you should drag the two files, jatzmail03.pyc and JATZMAILICON.png into a location where your path is avalible. (Because of this it also means the code is only workable on Windows) The default location for your path would C/Users/*your username*. Then go to your command prompt, and run: python jatzmail03.pyc


## Credits
This was made by Aidan and Jonathan, and the code is named JATZ mail
